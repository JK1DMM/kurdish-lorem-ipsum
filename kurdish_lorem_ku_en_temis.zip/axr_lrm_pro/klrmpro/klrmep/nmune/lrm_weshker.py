import numpy as np
import os


def klrmgenerator(n_wshe=30):
    yago_majuli = os.path.dirname(__file__)
    yago_faili = os.path.join(yago_majuli, 'krdic.txt')
    krdic = open(yago_faili, encoding='utf8').read()
    qsekan = krdic.split()

    def jut_weshker(qsekan):
        for i in range(len(qsekan)-1):
            yield (qsekan[i], qsekan[i+1])

    juts = jut_weshker(qsekan)

    wshe_dict = {}
    for wshe_1, wshe_2 in juts:
        if wshe_1 in wshe_dict.keys():
            wshe_dict[wshe_1].append(wshe_2)
        else:
            wshe_dict[wshe_1] = [wshe_2]

    ewel_wshe = np.random.choice(qsekan)
    chain = [ewel_wshe]

    for i in range(n_wshe):
        chain.append(np.random.choice(wshe_dict[chain[-1]]))

    klrm_weshkrya = ' '.join(chain)
    return klrm_weshkrya
