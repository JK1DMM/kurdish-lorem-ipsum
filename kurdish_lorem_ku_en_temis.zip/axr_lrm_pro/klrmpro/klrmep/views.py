from django.shortcuts import render
from django.http import HttpResponse
from django.template import loader
from klrmep.nmune.lrm_weshker import klrmgenerator


def lrmview_en(request):
    n = 200  # chn wshet gerekene
    template = loader.get_template('klrmep/index.html')
    lorem_kurdi = klrmgenerator(n)
    context = {
        'loremku': lorem_kurdi,
    }
    return HttpResponse(template.render(context))


def lrmview_ku(request):
    n = 200  # chn wshet gerekene
    template = loader.get_template('klrmep/index_ku.html')
    lorem_kurdi = klrmgenerator(n)
    context = {
        'loremku': lorem_kurdi,
    }
    return HttpResponse(template.render(context))
