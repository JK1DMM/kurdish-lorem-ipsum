from django.urls import path
from . import views

urlpatterns = [
    path('en/', views.lrmview_en, name='lrmview_en'),
    path('', views.lrmview_ku, name='lrmview_ku'),
]
